[Readme for Delete_JobReports.vbs]

-----------------------------DISCLAIMER-----------------------------
This script is not an official component of the RedDot Content 
Management Server, and is not supported or guaranteed by RedDot 
Solutions Corporation.  All claims of functionality are made by the 
script's author, and are not guaranteed by RedDot (regardless of any 
affiliation the author might have with RedDot Solutions). 

                      **USE AT YOR OWN RISK**
** THIS SCRIPT IS PROVIDED FREE OF CHARGE, AND MAY NOT BE RESOLD **

--------------------------------------------------------------------

This is a .VBS Script that uses RQL (the API for RedDot CMS)
to delete all publishing Job Reports for a single RedDot CMS 
project.  Job Reports are stored in the project database, and may 
consume considerable database size, over time, if not deleted.  
Use it with Windows Task Scheduler to schedule automatic/periodic
execution of the script.  (see below for details about using
Windows Task Scheduler.)


Author: Michael Madden (michael.madden@reddot.com)
Date:  September 18, 2002
Tested with RedDot version 4.5.2.8


***************** IMPORTANT: ******************

BEFORE USING, YOU MUST OPEN THE SCRIPT IN A TEXT EDITOR AND EDIT THE 
VARIABLES INDICATED UNDER THE HEADING "EDIT THESE VALUES".

There are 4 values which should be edited:

+ the username of the user accouint that should be used by the
script, which must log into the RedDot server to delete the job 
reports.

+ the password

+ the GUID of the project.  To determine the Project GUID, go to
RedDot Server Manager > Administer Projects > Projects > [Project
Name].  With the project name highlighted, click the small (i)
icon in the upper-right corner of the screen.  The GUID will be
displayed in a pop-up window.

+ whether or not the script should force a login (true or false).
If true, if the specified user is already logged in at the time the
script is executed, the existing session will be cancelled so the
script can start a new one.  If false, the script will NOT be
executed when the user is already logged in.

*************************************************

NOTE:  When the script is executed, it will run in the background.
It will not give any visual indication that it is running, nor when
it has finished.

USING WINDOWS TASK SCHEDULER:
-----------------------------

First open the "Scheduled Tasks" folder (Start > Programs > 
Accessories > System Tools > Scheduled Tasks).  Then, drag and drop 
the .vbs file into it.   Finally, in the Scheduled Tasks window, 
double-click the script name to edit the new task, then go to the 
Schedule tab to define the schedule according to your preferences.





