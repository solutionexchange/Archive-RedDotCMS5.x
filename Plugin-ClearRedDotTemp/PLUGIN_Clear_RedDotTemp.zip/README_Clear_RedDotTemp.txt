[ReadMe for plugin "Clear RedDotTemp Directory"]

PLUGIN:  Clear RedDotTemp Directory

SCRIPT AUTHOR:  Michael Madden (michael.madden@reddot.com)
VERSION: 1.0
DATE: December 12, 2002
TESTED WITH REDDOT CMS VERSION: 4.5.3.11
FILE(S):  Clear_RedDotTemp.asp
CUSTOM IMAGE(S): (none)
COPY TO DIRECTORY:  PlugIns

XML FOR PLUGINS FILE (PLUGINS.XML): 

	<PLUGIN name="Clear RedDotTemp Directory" url="Clear_RedDotTemp.asp" target="ioTreeProjectStart">
		<OPENWINDOWPARAMETER features="toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=0,resizable=1,width=1,height=1,screenX=500,screenY=350,left=500,top=350"/>
	</PLUGIN>

XML WORKS WITH TREE ELEMENT:  ioTreeProjectStart (Project node under "Admininster Project Structure")
OTHER POSSIBLE TREE ELEMENT(S):  Any

DESCRIPTION:  Deletes all files cached in RedDot's "RedDotTemp" directory,
which will cause all pages to be re-generated and re-published when 
publishing to an FTP target.

WARNING:  This plugin affects all projects on the server, not just the
active project.  

-----------------------------DISCLAIMER-----------------------------
This script is not an official component of the RedDot Content 
Management Server, and is not supported or guaranteed by RedDot 
Solutions Corporation.  All claims of functionality are made by the 
script's author, and are not guaranteed by RedDot (regardless of any 
affiliation the author might have with RedDot Solutions). 

                      **USE AT YOR OWN RISK**
** THIS SCRIPT IS PROVIDED FREE OF CHARGE, AND MAY NOT BE RESOLD **

--------------------------------------------------------------------