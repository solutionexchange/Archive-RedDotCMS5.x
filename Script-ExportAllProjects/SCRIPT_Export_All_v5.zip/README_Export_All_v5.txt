<<Readme for "export_all_v5.vbs">>

-----------------------------DISCLAIMER-----------------------------
This script is not an official component of the RedDot Content 
Management Server, and is not supported or guaranteed by RedDot 
Solutions Corporation.  All claims of functionality are made by the 
scripts author, and are not guaranteed by RedDot (regardless of any 
affiliation the author might have with RedDot Solutions). 

                      **USE AT YOR OWN RISK**
** THIS SCRIPT IS PROVIDED FREE OF CHARGE, AND MAY NOT BE RESOLD **

--------------------------------------------------------------------

DESCRIPTION:
RQL SCRIPT TO EXPORT ALL PROJECTS ON A SERVER, FOR USE WITH 
VERSION 5 ONLY!  CAN BE USED WITH WINDOWS TASK SCHEDULER OR
REDDOT'S SCHEDULED TASKS TO AUTOMATICALLY EXPORT AT REGULAR
INTERVALS.  CREATES SUB-DIRECTORIES BASED ON THE DATE AND 
PROJECT NAMES.

AUTHOR:  Michael Madden (michael.madden@reddot.com)
DATE:  May 2003
VERSION: 1.2
CMS COMPATIBILITY:  5.x only! (tested with 5.0.0.60)

INSTRUCTIONS:
(1) Open 'export_all_v5.vbs' in a text editor, such as Notepad, then edit the values
    indicated in the box below the heading "EDIT THESE VALUES".  There are additional
	instructions there.

(2) Test it by executing it manually, by double-clicking the .vbs file.  It must
	be executed directly on the RedDot server, not on a client machine!  Make
    sure that no errors are generated, and that projects are exported correctly.
    NOTE:  The script will give no visual indication when it is running, nor when
    it has finished.  Check the export path, RedDot's Export logs, and/or RedDot5.log
	to verify proper execution.

(3) Schedule automatic execution using Windows Task Scheduler, or using RedDots
    Scheduled Tasks feature (via the RedDot Server Manager).  It should be scheduled
    no more than once a day!