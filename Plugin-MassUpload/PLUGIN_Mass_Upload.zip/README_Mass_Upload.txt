[Readme for plugin "Mass Upload"]

NAME:  Mass Upload (Upload all files of directory)
SCRIPT AUTHOR:  Michael Madden (michael.madden@reddot.com)
VERSION: 1.0.1
DATE: May 7, 2003
COMPATIBLE CMS VERSIONS: 4.5, 5.0 (tested with 4.5.3.17 and 5.0.0.60)
FILE(S):  mass_upload.htm, mass_upload.asp, mass_upload2.asp, mass_upload3.asp, mass_upload_buttons.htm
CUSTOM IMAGE(S): (none)
COPY TO DIRECTORY:  PlugIns

XML FOR PLUGINS FILE (PLUGINS.XML): 

	<PLUGIN name="PLUGIN: Mass Upload" url="mass_upload.htm" target="ioTreeProject6050">
		<OPENWINDOWPARAMETER features="toolbar=0,location=0,directories=0,status=1,menubar=0,scrollbars=1,resizable=1,width=550,height=400,screenX=200,screenY=200,left=200,top=200"/>
		<ICON source="../ActionMenuIcons/Keywords.gif" alt=""/>
	</PLUGIN>

XML WORKS WITH TREE ELEMENT:  ioTreeProject6050 (Folders under Administer Project Settings)
OTHER POSSIBLE TREE ELEMENT(S):  (none)

DESCRIPTION:  Uploads all files in a selected directory 
(located on the Reddot Server) into the selected project folder.

CHANGES SINCE PREVIOUS VERSION:
* Now compatible with version 5.0, in addition to 4.5

WARNING:  After the uploading of files has started, closing the window
or clicking "Cancel" will not stop the upload process.  The script will
finish running in the background, even if the plugin window is closed.

-----------------------------DISCLAIMER-----------------------------
This script is not an official component of the RedDot Content 
Management Server, and is not supported or guaranteed by RedDot 
Solutions Corporation.  All claims of functionality are made by the 
script's author, and are not guaranteed by RedDot (regardless of any 
affiliation the author might have with RedDot Solutions). 

                      **USE AT YOR OWN RISK**
** THIS SCRIPT IS PROVIDED FREE OF CHARGE, AND MAY NOT BE RESOLD **

--------------------------------------------------------------------