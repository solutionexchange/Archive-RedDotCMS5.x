
PLUGIN NAME:  Reference Link in Clipboard for All Pages of Template
SCRIPT AUTHOR:  Michael Madden (michael.madden@reddot.com)
VERSION: 1.3
DATE: september 20, 2002
FILE(S):  linkref_allpages.asp, linkref_allpages2.asp, linkref_allpages3.asp
CUSTOM IMAGE(S): (none)
COPY TO DIRECTORY:  PlugIns

XML FOR PLUGINS FILE (PLUGINS.XML): 

	<PLUGIN name="Reference Link in Clipboard for All Pages of Template" url="linkref_allpages.asp" target="ioTreeProjectLink">
		<OPENWINDOWPARAMETER features="toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=1,resizable=1,width=500,height=400,screenX=200,screenY=200,left=200,top=200"/>
		<ICON source="../ActionMenuIcons/reference.gif" alt=""/>
	</PLUGIN>

XML WORKS WITH TREE ELEMENT:  ioTreeProjectLink (Link elements in project)
OTHER POSSIBLE TREE ELEMENT(S):  (none)

DESCRIPTION:  Works like the action "Reference Link in Clipboard", 
but the link reference can be applied to all pages that are also based on the same
template.  Exception: a link will not be made to reference itself.

CHANGES IN THIS VERSION:
* Increased script timeout to 5 minutes, to prevent script from 
timing-out when many pages are involved.
* Added "Loading..." and "Working..." messages to make it more clear
that something is happening while the script is executing.
* When the Plugin has finished, and the window is closed, the
SmartTree item  automatically refresh to show the change.   
However, only the selected item will refresh -- any other
visible tree objects that were affected by the Plugin will NOT
be refreshed automatically.
* (Version 1.2): You can now select which pages the reference will
be applied to, instead of automatically applying the reference to
all pages of the same template.

WARNINGS:  Will replace pre-existing references and connected 
pages.  Will not work if the selected link element is defined as
dynamic (link or container).

-----------------------------DISCLAIMER-----------------------------
This script is not an official component of the RedDot Content 
Management Server, and is not supported or guaranteed by RedDot 
Solutions Corporation.  All claims of functionality are made by the 
script's author, and are not guaranteed by RedDot (regardless of any 
affiliation the author might have with RedDot Solutions). 

                      **USE AT YOR OWN RISK**
** THIS SCRIPT IS PROVIDED FREE OF CHARGE, AND MAY NOT BE RESOLD **

--------------------------------------------------------------------
