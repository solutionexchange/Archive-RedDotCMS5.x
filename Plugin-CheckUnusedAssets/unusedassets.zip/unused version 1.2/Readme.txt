<!--
NAME:  Check for Unused Assets
AUTHOR:  Michael Madden (michael.madden@reddot.com)
VERSION: 1.2
DATE: August 13, 2003
COMPATIBLE CMS VERSIONS:  4.5, 5.0 (tested with 4.5.4.9 and 5.0.1.11)
FILES:  Check_Assets1.2_1.asp (this file), Check_Assets1.2_2.asp, Check_Assets1.2_3.asp, Check_Assets1.2_4.asp
CUSTOM IMAGE(S): (none)

XML FOR PLUGINS FILE (PLUGINS.XML): 

	<PLUGIN name="PLUGIN: Check for Unused Assets" url="Check_Assets1.2_1.asp" target="ioTreeProject6050" >
		<OPENWINDOWPARAMETER features="toolbar=0,location=0,directories=0,status=1,menubar=0,scrollbars=1,resizable=1,width=400,height=400,screenX=300,screenY=150,left=300,top=150"/>
		<ICON source="../ActionMenuIcons/ConnectExistingPage.gif" alt="Check for Unused Assets"/>
	</PLUGIN>

XML USES PLUGIN TARGET: ioTreeProject6050 (Folders under Administer Project Settings)
OTHER POSSIBLE PLUGIN TARGETS:  (none)

DESCRIPTION:  Checks for unused assets (files) in file folders.

CHANGES SINCE VERSION 1.0
* If the source file contains spaces, the plugin will convert spaces
to underscores (_) by default.  This can be deactivated via a checkbox
on the first screen.

* The plugin properly checks for image usage in Text elements in CMS 5.x

WARNINGS:
* This plugin may consume considerable server resources while it
is running, especially in large projects and/or folder with many
files.

* The plugin checks if files are used only in the current
and last-released versions of pages; therefore, if Versioning is
active, the plugin will not check for the usage of files in older
page versions. 

*If a folder is shared with another project, the plugin will NOT check
for the use of files in other projects; only the current project will
be checked.

ADDITIONAL NOTES:  In RedDot 5 and higher, the launching user must
have Server Manager rights, or the plugin will not work.

-----------------------------DISCLAIMER-----------------------------
This script is not an official component of the RedDot Content 
Management Server, and is not supported or guaranteed by RedDot 
Solutions Corporation.  All claims of functionality are made by the 
script's author, and are not guaranteed by RedDot (regardless of any 
affiliation the author might have with RedDot Solutions). 

                      **USE AT YOR OWN RISK**
** THIS SCRIPT IS PROVIDED FREE OF CHARGE, AND MAY NOT BE RESOLD **

--------------------------------------------------------------------